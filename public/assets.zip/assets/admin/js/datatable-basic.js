
$(document).ready(function() {

    $('.zero-configuration').DataTable();

});